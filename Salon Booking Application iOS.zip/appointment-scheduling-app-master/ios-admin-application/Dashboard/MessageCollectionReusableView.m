//
//  MessageCollectionReusableView.m
//  ios-admin-application
//
//  Created by Michail Grebionkin on 05.10.15.
//  Copyright © 2015 Michail Grebionkin. All rights reserved.
//

#import "MessageCollectionReusableView.h"

@implementation MessageCollectionReusableView

@end
