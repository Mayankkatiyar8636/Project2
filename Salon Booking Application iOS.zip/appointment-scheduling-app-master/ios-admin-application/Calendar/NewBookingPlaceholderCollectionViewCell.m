//
//  NewBookingPlaceholderCollectionViewCell.m
//  ios-admin-application
//
//  Created by Michail Grebionkin on 16.09.15.
//  Copyright © 2015 Michail Grebionkin. All rights reserved.
//

#import "NewBookingPlaceholderCollectionViewCell.h"

@implementation NewBookingPlaceholderCollectionViewCell

@end
