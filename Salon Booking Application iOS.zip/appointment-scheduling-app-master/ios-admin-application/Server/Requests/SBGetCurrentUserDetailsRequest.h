//
//  SBGetCurrentUserDetailsRequest.h
//  ios-admin-application
//
//  Created by Michail Grebionkin on 06.06.16.
//  Copyright © 2016 Michail Grebionkin. All rights reserved.
//

#import "SBRequestOperation.h"

@interface SBGetCurrentUserDetailsRequest : SBRequestOperation

@end
