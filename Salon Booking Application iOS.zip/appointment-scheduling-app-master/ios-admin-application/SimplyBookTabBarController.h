//
//  SimplyBookTabBarController.h
//  ios-admin-application
//
//  Created by Michail Grebionkin on 22.09.15.
//  Copyright © 2015 Michail Grebionkin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SimplyBookTabBarController : UITabBarController

@end

NS_ASSUME_NONNULL_END