//
//  LSBookingStatus+CoreDataProperties.m
//  ios-admin-application
//
//  Created by Michail Grebionkin on 24.03.16.
//  Copyright © 2016 Michail Grebionkin. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "LSBookingStatus+CoreDataProperties.h"

@implementation LSBookingStatus (CoreDataProperties)

@dynamic statusID;
@dynamic name;
@dynamic isDefault;
@dynamic hexColor;
@dynamic searchID;
@dynamic lastUpdate;

@end
