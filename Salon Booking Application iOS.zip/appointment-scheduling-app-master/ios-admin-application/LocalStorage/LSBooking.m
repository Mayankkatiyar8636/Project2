//
//  LSBooking.m
//  ios-admin-application
//
//  Created by Michail Grebionkin on 24.03.16.
//  Copyright © 2016 Michail Grebionkin. All rights reserved.
//

#import "LSBooking.h"

@implementation LSBooking

// Insert code here to add functionality to your managed object subclass

@end
