//
//  DashboardTopChartWidget.h
//  ios-admin-application
//
//  Created by Michail Grebionkin on 01.10.15.
//  Copyright © 2015 Michail Grebionkin. All rights reserved.
//

#import "DashboardSegmentedWidgetDataSource.h"

@interface DashboardTopChartWidget : DashboardSegmentedWidgetDataSource

@end
