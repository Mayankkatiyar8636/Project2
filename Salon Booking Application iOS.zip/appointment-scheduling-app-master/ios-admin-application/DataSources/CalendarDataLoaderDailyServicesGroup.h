//
//  CalendarDataLoaderDailyServicesGroup.h
//  ios-admin-application
//
//  Created by Michail Grebionkin on 28.10.16.
//  Copyright © 2016 Michail Grebionkin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CalendarDataLoaderFactory.h"

@interface CalendarDataLoaderDailyServicesGroup : NSObject<CalendarDataLoader> 

@end
